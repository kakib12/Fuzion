# Fuzion - AI Trading Signals Web App

This app uses Smart Money Strategy, RSI + EMA, Auto TP/SL, and FII/DII Confirmation.